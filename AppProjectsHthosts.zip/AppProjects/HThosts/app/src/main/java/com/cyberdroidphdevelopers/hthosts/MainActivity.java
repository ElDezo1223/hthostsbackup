package com.cyberdroidphdevelopers.hthosts;
import org.jsoup.Jsoup;
import org.jsoup.Connection.Response;
import org.jsoup.nodes.Document;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.support.design.*;
import android.support.design.widget.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.text.*;
import android.text.style.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.widget.AdapterView.*;
import com.squareup.picasso.*;
import java.io.*;
import java.util.regex.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import android.support.design.R;
import android.support.v7.widget.Toolbar;
import android.view.View.OnClickListener;
import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.*;
import java.util.*;
import android.widget.RadioGroup.*;
import android.preference.*;

public class MainActivity extends ActionBarActivity
{
    private Toolbar ttt;
    DrawerLayout dl;
    ActionBarDrawerToggle abdt;
    FragmentTransaction ft;
    FragmentTransaction nav_ft;
    NavigationView nv;
    SharedPreferences read_data;
    String result;
    String filename_extension;
    String[] divider;
    String[] data;
    String filen;
    String rensponse_gath;
    String[] file_g_del;
    String filename_del;
    Document del_rens;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		
		
		
		
		//refresh
		android.widget.Button refresh_btn = (android.widget.Button) findViewById(R.id.refresh_start_login_act);
		refresh_btn.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					MainActivity.this.finish();
					startActivity(new Intent(MainActivity.this,login_area.class));

				}


			});

			
		//end
		
		final FloatingActionMenu menu_bottom = (com.github.clans.fab.FloatingActionMenu) findViewById(R.id.menu_blue);
		read_data = getSharedPreferences("login_data",Context.MODE_PRIVATE); 
		data = read_data.getString("login_data","Default").split("#");
		del_file();
		up_file();
		new_file();
		name_file();
		final Spinner files = (Spinner) findViewById(R.id.files);

		LayoutInflater layout_fetcher = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
		final View paste_fetch = layout_fetcher.inflate(R.layout.navigation_drawer_header,null);
		/*a0p main ptefferences*/
		new Thread(new Runnable(){
				String listergath = "";

				@Override
				public void run()
				{
					try{
						Document file_list = Jsoup.connect("http://localhost:8080/hthosts/lister.php?username="+data[0]).get();
						listergath = file_list.wholeText();

						// TODO: Implement this method



					}catch(IOException e){

					}

					runOnUiThread(new Runnable(){
							String list_mirror = "";
							String y_mirror = "";
							@Override
							public void run()
							{

								divider = listergath.split("#");
								ArrayAdapter<String> list = new ArrayAdapter<String> (MainActivity.this,android.R.layout.simple_spinner_dropdown_item, divider);
								files.setAdapter(list);


							}});}
			}).start();
		files.setOnItemSelectedListener(new OnItemSelectedListener(){

				@Override
				public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
				{
					int item = files.getSelectedItemPosition();
					final String y= divider[item];
					filen = divider[item];
					new Thread(new Runnable(){

							@Override
							public void run()
							{
								try
								{
									final Document get = Jsoup.connect("http://localhost:8080/hthosts/gettext.php?username=" + data[0] + "&file=" + y).get();
									rensponse_gath = get.wholeText();
								}
								catch (IOException e)
								{}

								runOnUiThread(new Runnable(){

										@Override
										public void run()
										{

											EditText com = (EditText) findViewById(R.id.compiler);
											com.setText(rensponse_gath);





										}


									});

							}


						}).start();
				}

				@Override
				public void onNothingSelected(AdapterView<?> p1)
				{

				}


			});
		final EditText editText = (EditText) findViewById(R.id.compiler);

		final TextView line_count_display = (TextView) findViewById(R.id.line_count);
		for(int count = 1; count <= 550;count++){
			line_count_display.append(count+"\n");
		}
		editText.addTextChangedListener(new TextWatcher() {

				ColorScheme keywords = new ColorScheme(
					Pattern.compile(
						"\\b(<|>|html|head|DOCTYPE html|div|div|hr|h1|h2|h3|h4|h5|h6|title|p|style|script|meta|link|img|a href|href|form|input|div)\\b"),
					Color.BLUE
				);
				ColorScheme numbers = new ColorScheme(
					Pattern.compile("(\\b(\\d*[.]?\\d+)\\b)"),
					Color.GREEN
				);
                ColorScheme punctwithtext = new ColorScheme(
					Pattern.compile("\\p{Punct}"),
					Color.RED
				);
				final ColorScheme[] schemes = { punctwithtext, keywords, numbers };

				@Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {

				}

				@Override public void onTextChanged(CharSequence s, int start, int before, int countnum) {


				}

				@Override public void afterTextChanged(Editable s) {
					removeSpans(s, ForegroundColorSpan.class);
					for (ColorScheme scheme : schemes) {
						for(Matcher m = scheme.pattern.matcher(s); m.find();) {
							s.setSpan(new ForegroundColorSpan(scheme.color),
									  m.start(),
									  m.end(),
									  Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
						}
					}
				}

				void removeSpans(Editable e, Class<? extends CharacterStyle> type) {
					CharacterStyle[] spans = e.getSpans(0, e.length(), type);
					for (CharacterStyle span : spans) {
						e.removeSpan(span);
					}
				}

				class ColorScheme {
					final Pattern pattern;
					final int color;

					ColorScheme(Pattern pattern, int color) {
						this.pattern = pattern;
						this.color = color;
					}
				}

			});






		/*ended*/

		nv = (NavigationView) findViewById(R.id.nav_view);
		View navHeaderView = nv.inflateHeaderView(R.layout.navigation_drawer_header);
		TextView username_dashboard = (TextView) navHeaderView.findViewById(R.id.username_dashboard);
		TextView email_dashboard = (TextView) navHeaderView.findViewById(R.id.email_dashboard);
		ImageView profile_picture = (ImageView) navHeaderView.findViewById(R.id.profile_picture);
		//Set network Image
		Picasso.with(this)
			.load("http://localhost:8080/hthosts/developer.png")
			.placeholder(R.drawable.icon_file)
			.error(R.drawable.developer)
			.into(profile_picture);

		username_dashboard.setText(data[0]);
		Snackbar welcome_msg = Snackbar.make(findViewById(R.id.home),"Welcome Back! "+data[0],Snackbar.LENGTH_LONG);
		welcome_msg.show();
		email_dashboard.setText(data[2]);

		ttt = (Toolbar) findViewById(R.id.app_bar);
		setSupportActionBar(ttt);

		dl = (DrawerLayout) findViewById(R.id.drawer_layout);

		abdt = new ActionBarDrawerToggle(this,dl,ttt,R.string.drawer_open,R.string.drawer_close);

		dl.setDrawerListener(abdt);

		//This code will load the home fragment when
		//the application loaded the first time..



		// This code will change the toolbar title...


		getSupportActionBar().setTitle("Home");

		dl.closeDrawers();
		getSupportActionBar().setTitle("Home");

		//Now, to set the click event for navigation
		// drawers menu add the below code.....
	


		nv.setNavigationItemSelectedListener(

			new NavigationView.OnNavigationItemSelectedListener(){

				@Override
				public boolean onNavigationItemSelected(MenuItem p1)
				{

					switch(p1.getItemId()){

						case R.id.change_password:

							android.app.AlertDialog.Builder mod_pwd_layout = new android.app.AlertDialog.Builder(MainActivity.this);
							LayoutInflater mod_layout_fetcher0 = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
							final View mod_layout_paste = mod_layout_fetcher0.inflate(R.layout.password_modifcation,null);
							mod_pwd_layout.setView(mod_layout_paste);
							Button logout_mod_pwd = (Button) mod_layout_paste.findViewById(R.id.mod_pwd_btn);
							mod_pwd_layout.setOnCancelListener(new DialogInterface.OnCancelListener(){

									@Override
									public void onCancel(DialogInterface p1)
									{
										startActivity(new Intent(MainActivity.this,MainActivity.class));
										MainActivity.this.finish();
									}


								});
							final CheckBox password_visibility = (CheckBox) mod_layout_paste.findViewById(R.id.check_password_visible);
							final EditText mod_new = (EditText) mod_layout_paste.findViewById(R.id.mod_pwd_newpwd);
							EditText mod_old = (EditText) mod_layout_paste.findViewById(R.id.mod_pwd_oldpwd);
							mod_old.setInputType(InputType.TYPE_CLASS_TEXT |InputType.TYPE_TEXT_VARIATION_PASSWORD);
							password_visibility.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

									@Override
									public void onCheckedChanged(CompoundButton p1, boolean p2)
									{
										if(password_visibility.isChecked()){
											mod_new.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
										}else{
											
											mod_new.setInputType(InputType.TYPE_CLASS_TEXT |InputType.TYPE_TEXT_VARIATION_PASSWORD);
										}
									}
									
				
			});

					logout_mod_pwd.setOnClickListener(new OnClickListener(){

							@Override
							public void onClick(View p1)
							{
								EditText mod_old = (EditText) mod_layout_paste.findViewById(R.id.mod_pwd_oldpwd);
								EditText mod_new = (EditText) mod_layout_paste.findViewById(R.id.mod_pwd_newpwd);
								final String mod_string_old = mod_old.getText().toString();
								final String mod_string_new = mod_new.getText().toString();
								final SharedPreferences passsaver = getSharedPreferences("login_data", MODE_PRIVATE);



								new Thread(new Runnable(){

										@Override
										public void run()
										{
											if(mod_string_old.equals(passsaver.getString("login_data","Default").split("#")[1])){

												try{

													Document mod_rens = Jsoup.connect("http://localhost:8080/hthosts/change_password_listener.php")
														.data("oldpassword",mod_string_old)
														.data("newpassword",mod_string_new)
														.data("email",data[0])
														.userAgent("Mozilla")
														.get();
													Snackbar rens_a = Snackbar.make(findViewById(R.id.home),mod_rens.wholeText(),Snackbar.LENGTH_LONG);
													rens_a.show();

												}catch(IOException e){

												}}else{
												Snackbar rens_a = Snackbar.make(findViewById(R.id.home),"Old Password doesn't match",Snackbar.LENGTH_LONG);
												rens_a.show();
											}
										}


									}).start();

							} });

					mod_pwd_layout.create().show();
					break;
				case R.id.logout_acc:
					android.app.AlertDialog.Builder logout_layout = new android.app.AlertDialog.Builder(MainActivity.this);
					LayoutInflater logout_fetcher_logout0 = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
					View logout_layout_paste = logout_fetcher_logout0.inflate(R.layout.logout_account,null);
					logout_layout.setView(logout_layout_paste);
					Button logout = (Button) logout_layout_paste.findViewById(R.id.confirm_logout);
					logout_layout.setOnCancelListener(new DialogInterface.OnCancelListener(){

							@Override
							public void onCancel(DialogInterface p1)
							{
								startActivity(new Intent(MainActivity.this,MainActivity.class));
								MainActivity.this.finish();
							}


						});
					logout.setOnClickListener(new OnClickListener(){

							@Override
							public void onClick(View p1)
							{
								// TODO: Implement this method


								SharedPreferences preferences = getSharedPreferences("login_data", 0);
								preferences.edit().clear().commit();
								startActivity(new Intent(MainActivity.this,login_area.class));
								MainActivity.this.finish();

							}	 });

					logout_layout.create().show();}

				// TODO: Implement this method
				return false;
			}


	}

	);
}

    @Override
    protected void onPostCreate(Bundle savedInstanceState)
    {
	// TODO: Implement this method
	super.onPostCreate(savedInstanceState);
	abdt.syncState();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu aaa)
    {
	MenuInflater bbb = getMenuInflater();
	bbb.inflate(R.menu.my_menu,aaa);

	// TODO: Implement this method
	return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem ccc)
    {
	if(ccc.getItemId() == R.id.save){
	    //file_selected

	    final EditText compiled_code = (EditText) findViewById(R.id.compiler);
	    read_data = getSharedPreferences("login_data",Context.MODE_PRIVATE); 
	    data = read_data.getString("login_data","Default").split("#");
	    new Thread(new Runnable(){
		    String rensponse_gath_post2;
		    @Override
		    public void run()
		    {
			try
			{

			    Document get = Jsoup.connect("http://localhost:8080/hthosts/create_file_listener.php")
				.data("username",data[0])
				.data("code",compiled_code.getText().toString())
				.data("filename",filen)
				.userAgent("Mozilla")
				.post();

			    rensponse_gath_post2 = get.wholeText();
			    runOnUiThread(new Runnable(){

				    @Override
				    public void run()
				    {
					if(!rensponse_gath_post2.equals("Success")){
					    Snackbar toast_post2 = Snackbar.make(findViewById(R.id.home),"Null recieved,invalid reciept.",Snackbar.LENGTH_LONG);
					    toast_post2.show();
					    startActivity(new Intent(MainActivity.this, login_area.class));
					    MainActivity.this.finish();
					}else{
					    Snackbar toast_post2 = Snackbar.make(findViewById(R.id.home),"file saved.",Snackbar.LENGTH_LONG);
					    toast_post2.show();
					}
				    }


				});
			}
			catch (IOException e)
			{
			    Snackbar toast_post2 = Snackbar.make(findViewById(R.id.home),"An IOexeption Occured.",Snackbar.LENGTH_LONG);
			    toast_post2.show();
			}
		    }


		}).start();
	}
	if(ccc.getItemId() == R.id.run){
		startActivity(new Intent(MainActivity.this,run_webview.class));
		
	}
	// TODO: Implement this methodi
	return true;
    }

    private void up_file(){
		final FloatingActionMenu menu_bottom = (com.github.clans.fab.FloatingActionMenu) findViewById(R.id.menu_blue);
		final android.app.AlertDialog.Builder upload_float = new android.app.AlertDialog.Builder(MainActivity.this);
		LayoutInflater layout_fetcher0= (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
		final View layout_paste = layout_fetcher0.inflate(R.layout.upload_file,null);
		upload_float.setView(layout_paste);

		final android.app.AlertDialog upload_float_create = upload_float.create();

		final FloatingActionButton upload_file = (com.github.clans.fab.FloatingActionButton) findViewById(R.id.fab1);
		android.widget.Button upload_send_btn = (android.widget.Button) layout_paste.findViewById(R.id.upload_btn);
		final Spinner extension = (Spinner) layout_paste.findViewById(R.id.uploadfileSpinner);
		final String[] extensionArray = {".html",".css",".js"};
		ArrayAdapter<String> list = new ArrayAdapter<String> (MainActivity.this,android.R.layout.simple_spinner_dropdown_item, extensionArray);
		extension.setAdapter(list);
		extension.setOnItemSelectedListener(new OnItemSelectedListener(){

				@Override
				public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
				{

					filename_extension = extensionArray[extension.getSelectedItemPosition()];
				}

				@Override
				public void onNothingSelected(AdapterView<?> p1)
				{
					// TODO: Implement this method
				}


			});
		upload_send_btn.setOnClickListener(new OnClickListener(){


				@Override
				public void onClick(View p1)
				{

					final EditText path_file = (EditText) layout_paste.findViewById(R.id.path_file);
					final EditText name_file = (EditText) layout_paste.findViewById(R.id.name_file);
					final File check = new File(Environment.getExternalStorageDirectory()+"/"+path_file.getText().toString());
					if(check.isFile()){

						new Thread(new Runnable(){
								@Override
								public void run(){

									try {
										Document coderes = Jsoup.parse(new File(Environment.getExternalStorageDirectory()+"/"+path_file.getText().toString()), "UTF-8","http://localhost:8080/hthosts/");
										final Document poster = Jsoup.connect("http://localhost:8080/hthosts/create_file_listener.php")
											.data("username",data[0])
											.data("filename",name_file.getText().toString()+filename_extension)
											.data("code",coderes.select("html").toString())
											.userAgent("Mozilla")
											.post();
										result = poster.wholeText();
										runOnUiThread(new Runnable(){

												@Override
												public void run()
												{
													if(poster.wholeText().equals("Success")){
														Snackbar result_alert = Snackbar.make(findViewById(R.id.home),result,Snackbar.LENGTH_LONG);
														result_alert.show();
														startActivity(new Intent(MainActivity.this, login_area.class));
														MainActivity.this.finish();
													}else{
														Snackbar result_alert = Snackbar.make(findViewById(R.id.home),"Null recieved,invalid reciept.",Snackbar.LENGTH_LONG);
														result_alert.show();

													}
												}


											});
										//get the cookies





									} catch (IOException e) {
										// TODO Auto-generated catch block
										final String i =  e.toString();
										Snackbar result_alert = Snackbar.make(findViewById(R.id.home),"An IOEXception Occured.",Snackbar.LENGTH_LONG);
										result_alert.show();
										runOnUiThread(new Runnable(){

												@Override
												public void run()
												{
													// TODO: Implement this method



													// Toast.makeText(MainActivity.this,i.toString(),Toast.LENGTH_LONG).show();
												}}); }
								}

							}).start();
					}else{
						Snackbar err = Snackbar.make(findViewById(R.id.home),check.getAbsolutePath()+" Is not Exists.",Snackbar.LENGTH_LONG);
						err.show();

					}
				}


			});
		upload_file.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{

					upload_float.create().show();
					menu_bottom.hideMenu(true);


				}


			});
		upload_float.setOnCancelListener(new DialogInterface.OnCancelListener(){

				@Override
				public void onCancel(DialogInterface p1)
				{
					startActivity(new Intent(MainActivity.this, login_area.class));
					MainActivity.this.finish();
				}


			});
    }
    private void del_file(){
		final Spinner files = (Spinner) findViewById(R.id.files);
		final android.app.AlertDialog.Builder delete_dialog = new android.app.AlertDialog.Builder(MainActivity.this);
		final FloatingActionButton delete_file_button = (com.github.clans.fab.FloatingActionButton) findViewById(R.id.fab3);
		delete_file_button.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					delete_dialog.create().show();
				}


			});

        LayoutInflater layout_fetcher_delete = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
		final View layout_paste_delete = layout_fetcher_delete.inflate(R.layout.delete_file_layout,null);
		delete_dialog.setView(layout_paste_delete);
		Button delete = (Button) layout_paste_delete.findViewById(R.id.delete_btn);
		TextView para_del = (TextView) layout_paste_delete.findViewById(R.id.delete_file_para);

		delete.setOnClickListener(new OnClickListener(){

				@Override
				String y;
				public void onClick(View p1)
				{




					new Thread(new Runnable(){

							@Override
							public void run()
							{
								try{
									final Document  del_rens = Jsoup.connect("http://localhost:8080/hthosts/delete_file_listener.php")
										.data("username",data[0])
										.data("filename",divider[files.getSelectedItemPosition()])
										.userAgent("Mozilla")
										.post();
									runOnUiThread(new Runnable(){

											@Override
											public void run()
											{
												if(del_rens.wholeText().equals("File Deleted.")){
													Snackbar rens = Snackbar.make(findViewById(R.id.home),del_rens.wholeText(),Snackbar.LENGTH_LONG);
													rens.show();
													startActivity(new Intent(MainActivity.this, login_area.class));
													MainActivity.this.finish();
												}else{
													Snackbar rens = Snackbar.make(findViewById(R.id.home),"Null Reciept,Invalid",Snackbar.LENGTH_LONG);
													rens.show();
												}}
										});
								}catch(IOException err){
									Snackbar rens = Snackbar.make(findViewById(R.id.home),"An IOException recieved.",Snackbar.LENGTH_LONG);
									rens.show(); 
								}
							}}).start();

				}
			});
		delete_dialog.setOnCancelListener(new DialogInterface.OnCancelListener(){

				@Override
				public void onCancel(DialogInterface p1)
				{
					MainActivity.this.finish();
					startActivity(new Intent(MainActivity.this,MainActivity.class));
				}


			});
	}
    private void new_file(){
		//a copied version for new_file
		final FloatingActionMenu menu_bottom = (com.github.clans.fab.FloatingActionMenu) findViewById(R.id.menu_blue);
		final android.app.AlertDialog.Builder upload_float = new android.app.AlertDialog.Builder(MainActivity.this);
		LayoutInflater layout_fetcher0= (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
		final View layout_paste = layout_fetcher0.inflate(R.layout.new_file_layout,null);
		upload_float.setView(layout_paste);

		final android.app.AlertDialog upload_float_create = upload_float.create();

		final FloatingActionButton upload_file = (com.github.clans.fab.FloatingActionButton) findViewById(R.id.fab2);
		android.widget.Button upload_send_btn = (android.widget.Button) layout_paste.findViewById(R.id.named_btn);
		final Spinner extension = (Spinner) layout_paste.findViewById(R.id.newfileSpinner);
		final String[] extensionArray = {".html",".css",".js"};
		ArrayAdapter<String> list = new ArrayAdapter<String> (MainActivity.this,android.R.layout.simple_spinner_dropdown_item, extensionArray);
		extension.setAdapter(list);
		extension.setOnItemSelectedListener(new OnItemSelectedListener(){

				@Override
				public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
				{

					filename_extension = extensionArray[extension.getSelectedItemPosition()];
				}

				@Override
				public void onNothingSelected(AdapterView<?> p1)
				{
					// TODO: Implement this method
				}


			});
		upload_send_btn.setOnClickListener(new OnClickListener(){


				@Override
				public void onClick(View p1)
				{
					final EditText name_file = (EditText) layout_paste.findViewById(R.id.name_file);



					new Thread(new Runnable(){
							@Override
							public void run(){

								try {

									Document poster = Jsoup.connect("http://localhost:8080/hthosts/create_file_listener.php")
										.data("username",data[0])
										.data("filename",name_file.getText().toString()+filename_extension)
										.userAgent("Mozilla")
										.post();
									result = poster.wholeText();
									runOnUiThread(new Runnable(){

											@Override
											public void run()
											{
												if(result.equals("Success")){


													Snackbar result_alert = Snackbar.make(findViewById(R.id.home),result,Snackbar.LENGTH_LONG);
													result_alert.show();
													startActivity(new Intent(MainActivity.this, login_area.class));
													MainActivity.this.finish();
												}else{
													Snackbar result_alert = Snackbar.make(findViewById(R.id.home),"Null recieved,invalid reciept.",Snackbar.LENGTH_LONG);
													result_alert.show();

												}
											}


										});
									//get the cookies





								} catch (IOException e) {
									// TODO Auto-generated catch block
									final String i =  e.toString();
									Snackbar result_alert = Snackbar.make(findViewById(R.id.home),"An IOException Occured",Snackbar.LENGTH_LONG);
									result_alert.show();
									runOnUiThread(new Runnable(){

											@Override
											public void run()
											{
												// TODO: Implement this method



												// Toast.makeText(MainActivity.this,i.toString(),Toast.LENGTH_LONG).show();
											}}); }
							}

						}).start();

				}


			});
		upload_file.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{

					upload_float.create().show();
					menu_bottom.hideMenu(true);


				}


			});
		upload_float.setOnCancelListener(new DialogInterface.OnCancelListener(){

				@Override
				public void onCancel(DialogInterface p1)
				{
					startActivity(new Intent(MainActivity.this, login_area.class));
					MainActivity.this.finish();
				}


			});
    }
    private void name_file(){
		//a copied version for name_file
		final Spinner files = (Spinner) findViewById(R.id.files);
		final FloatingActionMenu menu_bottom = (com.github.clans.fab.FloatingActionMenu) findViewById(R.id.menu_blue);
		final android.app.AlertDialog.Builder upload_float = new android.app.AlertDialog.Builder(MainActivity.this);
		LayoutInflater layout_fetcher0= (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
		final View layout_paste = layout_fetcher0.inflate(R.layout.rename_file_layout,null);
		upload_float.setView(layout_paste);

		final android.app.AlertDialog upload_float_create = upload_float.create();

		final FloatingActionButton upload_file = (com.github.clans.fab.FloatingActionButton) findViewById(R.id.fab4);
		android.widget.Button upload_send_btn = (android.widget.Button) layout_paste.findViewById(R.id.proc_ren_btn);
		final Spinner extension = (Spinner) layout_paste.findViewById(R.id.newffileSpinner);
		final String[] extensionArray = {".html",".css",".js"};
		ArrayAdapter<String> list = new ArrayAdapter<String> (MainActivity.this,android.R.layout.simple_spinner_dropdown_item, extensionArray);
		extension.setAdapter(list);

		upload_send_btn.setOnClickListener(new OnClickListener(){


				@Override
				public void onClick(View p1)
				{
					final EditText name_file = (EditText) layout_paste.findViewById(R.id.new_name_file);



					new Thread(new Runnable(){
							@Override
							public void run(){

								try {

									final Document poster = Jsoup.connect("http://localhost:8080/hthosts/rename.php")
										.data("username",data[0])
										.data("tmpfile",divider[files.getSelectedItemPosition()])
										.data("newfile",name_file.getText().toString()+extensionArray[extension.getSelectedItemPosition()])
										.userAgent("Mozilla")
										.post();
									result = poster.wholeText();
									runOnUiThread(new Runnable(){

											@Override
											public void run()
											{
												;
												if(poster.wholeText().equals("Success")){
													Snackbar result_alert = Snackbar.make(findViewById(R.id.home),result,Snackbar.LENGTH_LONG);
													result_alert.show();
													startActivity(new Intent(MainActivity.this, login_area.class));
													MainActivity.this.finish();
												}else{
													Snackbar result_alert = Snackbar.make(findViewById(R.id.home),"Null recieved,invalid reciept.",Snackbar.LENGTH_LONG);
													result_alert.show();

												}
											}


										});
								} catch (IOException e) {
									// TODO Auto-generated catch block
									final String i =  e.toString();
									Snackbar result_alert = Snackbar.make(findViewById(R.id.home),"An IOException occured.",Snackbar.LENGTH_LONG);
									result_alert.show();
									runOnUiThread(new Runnable(){

											@Override
											public void run()
											{
											}}); }
							}

						}).start();

				}


			});
		upload_file.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{

					upload_float.create().show();
					menu_bottom.hideMenu(true);


				}


			});
		upload_float.setOnCancelListener(new DialogInterface.OnCancelListener(){

				@Override
				public void onCancel(DialogInterface p1)
				{
					startActivity(new Intent(MainActivity.this, login_area.class));
					MainActivity.this.finish();
				}


			});
    }
	
}

