package com.cyberdroidphdevelopers.hthosts;
import android.support.v7.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.view.View.*;
import android.support.design.widget.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import java.io.*;
import android.content.*;
public class login_area extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
	// TODO: Implement this method
	final EditText username;
	final EditText password;
	Button login;
	super.onCreate(savedInstanceState);
	setContentView(R.layout.login_background);
	
	SharedPreferences read_data = getSharedPreferences("login_data", MODE_PRIVATE);
	if(!read_data.getString("login_data","").equals("")){
	    startActivity(new Intent(login_area.this, MainActivity.class));
	this.finish();
	    }else{
	AlertDialog.Builder login_float = new AlertDialog.Builder(this);
 LayoutInflater layout_fetcher = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
 final View paste_fetch = layout_fetcher.inflate(R.layout.login_layout,null);

 login_float.setView(paste_fetch);
 login_float.setCancelable(false);
 username = (EditText) paste_fetch.findViewById(R.id.username_login);
 password = (EditText) paste_fetch.findViewById(R.id.password_login);
 login = (Button) paste_fetch.findViewById(R.id.button_login);
	login.setOnClickListener(new OnClickListener(){

		@Override
		public void onClick(View p1)
		{
		 final   StringBuilder result = new StringBuilder();
		final StringBuilder email_gath = new StringBuilder();
		 Snackbar loading = Snackbar.make(paste_fetch.findViewById(R.id.login_layoutLinearLayout),"Please wait...",Snackbar.LENGTH_LONG);

		    loading.show();
		  new Thread(new Runnable(){

			    @Override
			    public void run()
			    {
		  try
		    {
			Document   login = Jsoup.connect("http://localhost:8080/hthosts/login.php?username="+username.getText().toString()+"&password="+password.getText().toString()).get();
		result.append(login.wholeText());
		Document catch_datas = Jsoup.connect("http://localhost:8080/hthosts/database.bin/"+username.getText().toString()+"/email.xml").get();
			email_gath.append(catch_datas.wholeText());
		}
		    catch (IOException e)
		    {
			Snackbar error = Snackbar.make(paste_fetch.findViewById(R.id.login_layoutLinearLayout),"Database connection has stopped.",Snackbar.LENGTH_LONG);
			error.show();
		} 
				runOnUiThread(new Runnable(){

					@Override
					public void run()
					{
					    if(result.toString().equals("please enter your password correctly")){
						Snackbar result_text = Snackbar.make(paste_fetch.findViewById(R.id.login_layoutLinearLayout),result.toString(),Snackbar.LENGTH_LONG);
						result_text.setAction("RESET PASSWORD", new View.OnClickListener(){

							@Override
							public void onClick(View p1)
							{
							  
							}
							
						    
						});
						result_text.show();
						
					    
						
					    }else if(result.toString().equals("")){
						Snackbar result_text = Snackbar.make(paste_fetch.findViewById(R.id.login_layoutLinearLayout),"Null recieved,a invalid reciept.",Snackbar.LENGTH_LONG);
						result_text.show();
					    }
					    else{
					    Snackbar result_text = Snackbar.make(paste_fetch.findViewById(R.id.login_layoutLinearLayout),result.toString(),Snackbar.LENGTH_LONG);
					    result_text.show();
					    }		
					    if(result.toString().equals("Successfully logged in!")){
					    SharedPreferences save_login_log = getSharedPreferences("login_data",Context.MODE_PRIVATE);
					    SharedPreferences.Editor new_login = save_login_log.edit();
					    String catch_data = username.getText().toString()+"#"+password.getText().toString()+"#"+email_gath.toString();

						new_login.putString("login_data",catch_data);
						new_login.commit();
						startActivity(new Intent(login_area.this,MainActivity.class));
					}    }
					
		    
		});
		}}).start();loading.show();}
	    
	});
	
 login_float.create().show();
	}}
 
}
