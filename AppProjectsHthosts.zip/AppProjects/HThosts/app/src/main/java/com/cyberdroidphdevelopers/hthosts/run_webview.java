package com.cyberdroidphdevelopers.hthosts;

import org.jsoup.Jsoup;
import org.jsoup.Connection.Response;
import org.jsoup.nodes.Document;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.support.design.*;
import android.support.design.widget.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.text.*;
import android.text.style.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.widget.AdapterView.*;
import com.squareup.picasso.*;
import java.io.*;
import java.util.regex.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import android.support.design.R;
import android.support.v7.widget.Toolbar;
import android.view.View.OnClickListener;
import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.*;
import java.util.*;
import android.widget.RadioGroup.*;
import android.preference.*;

public class run_webview extends ActionBarActivity
{
    
	@Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.run_activity);
		

	
		Toolbar toolbar = (Toolbar)findViewById(R.id.app_bar);

        setSupportActionBar(toolbar);
		
		getSupportActionBar().setTitle("Run");
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		
	}

    

}
